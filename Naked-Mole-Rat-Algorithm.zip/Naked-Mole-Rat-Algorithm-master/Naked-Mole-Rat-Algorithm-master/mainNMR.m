%___________________________________________________________________%
% Naked Mole Rat Algorithm(NMRA) source codes demo version 1.0      %
%___________________________________________________________________%

% You can simply define your cost in a seperate file and load its handle to fobj 
% The initial parameters that you need are:
%__________________________________________
% fobj = @YourCostFunction
% dim = number of your variables
% Max_iteration = maximum number of generations
% NMR_pop = number of search agents
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define lb and ub as two single number numbers

% To run NMR: [Best_score,Best_pos,cg_curve]=NMRA(NMR_pop ,Max_iteration,lb,ub,dim,fobj)
%__________________________________________

clear all 
clc

NMR_pop=40; % Number of NMRs
Function_name='sphere'; % Name of the test function
Max_iteration=500; % Maximum number of iterations

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=NMR_function_details(Function_name);
%Run NMR Algorithm
[Best_NMR,Best_NMRpos,cg_curve]=NMRA(ub,lb,dim,fobj,Max_iteration,NMR_pop)

% %Draw objective space
semilogy(cg_curve,'Color','r')
title('Convergence curve')
xlabel('Iteration');
ylabel('Best score obtained so far');

axis tight
grid off
box on
legend('NMRA')

display(['The best solution obtained by NMRA is : ', num2str(Best_NMRpos')]);
display(['The best optimal value of the objective funciton found by NMRA is : ', num2str(Best_NMR)]);

        



