function[Ub,Lb,Dim,Fun]=NMR_function_details(F)
switch F
    case 'sphere' %1
        Fun = @sphere;
        Ub=100;
        Lb=-100;
        Dim=30;
    case 'rastrigin'%2
        Fun = @rastrigin;
        Ub=5.12;
        Lb=-5.12;
        Dim=30;
    case 'griewank'%3
        Fun = @griewank;
        Ub=600;
        Lb=-600;
        Dim=30;
      case 'ackley'%4
        Fun = @ackley;
        Ub=32;
        Lb=-32;
        Dim=30;
end
end
function o = sphere(x)%1
o=sum(x.^2);
end
function o=rastrigin(x)%2
x1=x(1);
x2=x(2);
o= x1.^2 + x2.^2 - 10*cos(2*pi*x1) - 10*cos(2*pi*x2) + 20;
end
function o=griewank(x)%3
x1=x(1);
x2=x(2);
o= (x1.^2 + x2.^2)/200 - cos(x1).*cos(x2/sqrt(2)) + 1;
end
function o = ackley(x)%4
dim=size(x,2);
o=-20*exp(-.2*sqrt(sum(x.^2)/dim))-exp(sum(cos(2*pi.*x))/dim)+20+exp(1);
end